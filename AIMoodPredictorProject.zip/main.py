import json
import requests
def get_prediction(sentence):
  data = {"sentence": sentence}
  url = 'https://askai.aiclub.world/934de36f-d856-4e2e-b126-be18d9a2c88b'
  r = requests.post(url, data=json.dumps(data))
  response = getattr(r, '_content').decode("utf-8")
  predicted_label = json.loads(json.loads(response)['body'])['predicted_label']
  return predicted_label
sentence = "Hello I am Frank. I am your Google Assistant. Let's talk!"
print(sentence)
name = input("What would you like to be called?")
print("Nice to meet you,", name, "!")
age = input("How old are you?")
print("Wow!", age, "is a great age!")
print("Let's talk some more.")
more_input = input("How are you feeling today?")
mood = get_prediction(more_input)
if mood == "happy":
  print("Glad to know that you are happy today!")
elif mood=="sad":
  print("I'm so sorry that you are sad today. Let's talk some more.")
  game_condition=input("Do you like to play games? Say yes or no.")
  if game_condition=="yes":
    print("Please play a game and see if you are feeling better.")
  else:
    print("Perhaps, there is something else you would like to do.")
else:
  print("Sorry, I don't understand.")